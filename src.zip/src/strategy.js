function calculateSMA(values, period) {
    if (values.length < period) {
        return null;
    }

    const recentValues = values.slice(-period);

    const sum = recentValues.reduce(
        (total, value) => total + value,
        0
    );

    return sum / period;
}

function getSignal(candles) {
    const closes = candles.map((candle) => candle.close);

    if (closes.length < 51) {
        return "HOLD";
    }

    // Current candle
    const currentFast = calculateSMA(closes, 20);
    const currentSlow = calculateSMA(closes, 50);

    // Previous candle
    const previousCloses = closes.slice(0, -1);

    const previousFast = calculateSMA(previousCloses, 20);
    const previousSlow = calculateSMA(previousCloses, 50);

    if (
        previousFast <= previousSlow &&
        currentFast > currentSlow
    ) {
        return "BUY";
    }

    if (
        previousFast >= previousSlow &&
        currentFast < currentSlow
    ) {
        return "SELL";
    }

    return "HOLD";
}

module.exports = {
    calculateSMA,
    getSignal,
};