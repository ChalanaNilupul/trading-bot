const { getHistoricalCandles } = require("./binance");
const { calculateSMA } = require("./strategy");

const SYMBOL = "BTCUSDT";
const INTERVAL = "1m";

const STARTING_BALANCE = 1000;
const FEE_RATE = 0.001; // 0.1%

// Risk management
const POSITION_SIZE = 0.10; // 10% of cash
const STOP_LOSS = 0.01;     // 1%
const TAKE_PROFIT = 0.02;   // 2%

async function runBacktest() {
    console.log("\n==============================");
    console.log("        BACKTEST V1.2");
    console.log("==============================");

    const candles = await getHistoricalCandles(
    SYMBOL,
    INTERVAL,
    10000
);

    if (candles.length < 51) {
        console.log("Not enough candle data.");
        return;
    }

    let cash = STARTING_BALANCE;
    let btc = 0;

    let entryPrice = null;
    let entryValue = null;

    let trades = [];

    let winningTrades = 0;
    let losingTrades = 0;

    let stopLossTrades = 0;
    let takeProfitTrades = 0;
    let signalExitTrades = 0;

    let peakBalance = STARTING_BALANCE;
    let maxDrawdown = 0;

    for (let i = 50; i < candles.length; i++) {
        const candle = candles[i];

        const currentCloses = candles
            .slice(0, i + 1)
            .map((c) => c.close);

        const previousCloses = candles
            .slice(0, i)
            .map((c) => c.close);

        const currentFast = calculateSMA(
            currentCloses,
            20
        );

        const currentSlow = calculateSMA(
            currentCloses,
            50
        );

        const previousFast = calculateSMA(
            previousCloses,
            20
        );

        const previousSlow = calculateSMA(
            previousCloses,
            50
        );

        const buySignal =
            previousFast <= previousSlow &&
            currentFast > currentSlow;

        const sellSignal =
            previousFast >= previousSlow &&
            currentFast < currentSlow;

        /*
         * ==========================================
         * POSITION MANAGEMENT
         * ==========================================
         */

        if (btc > 0) {
            const stopPrice =
                entryPrice * (1 - STOP_LOSS);

            const targetPrice =
                entryPrice * (1 + TAKE_PROFIT);

            /*
             * We use the candle's LOW/HIGH because
             * the exact price path inside the candle
             * is unknown.
             */

            let exitPrice = null;
            let exitReason = null;

            // Stop loss
            if (candle.low <= stopPrice) {
                exitPrice = stopPrice;
                exitReason = "STOP LOSS";
            }

            // Take profit
            else if (candle.high >= targetPrice) {
                exitPrice = targetPrice;
                exitReason = "TAKE PROFIT";
            }

            // Strategy exit
            else if (sellSignal) {
                exitPrice = candle.close;
                exitReason = "SIGNAL";
            }

            if (exitPrice !== null) {
                const exitValue =
                    btc * exitPrice;

                const exitFee =
                    exitValue * FEE_RATE;

                const entryFee =
                    entryValue * FEE_RATE;

                const grossPnL =
                    exitValue - entryValue;

                const totalFees =
                    entryFee + exitFee;

                const netPnL =
                    grossPnL - totalFees;

                cash +=
                    exitValue - exitFee;

                const trade = {
                    entryPrice,
                    exitPrice,
                    reason: exitReason,
                    grossPnL,
                    fees: totalFees,
                    netPnL,
                };

                trades.push(trade);

                if (netPnL >= 0) {
                    winningTrades++;
                } else {
                    losingTrades++;
                }

                if (exitReason === "STOP LOSS") {
                    stopLossTrades++;
                }

                if (exitReason === "TAKE PROFIT") {
                    takeProfitTrades++;
                }

                if (exitReason === "SIGNAL") {
                    signalExitTrades++;
                }

                console.log(
                    `${exitReason.padEnd(11)} ` +
                    `$${exitPrice.toFixed(2)} ` +
                    `| P/L: $${netPnL.toFixed(2)}`
                );

                btc = 0;
                entryPrice = null;
                entryValue = null;
            }
        }

        /*
         * ==========================================
         * ENTRY
         * ==========================================
         */

        if (buySignal && btc === 0) {
            const amountToSpend =
                cash * POSITION_SIZE;

            const entryFee =
                amountToSpend * FEE_RATE;

            const btcBought =
                amountToSpend / candle.close;

            if (
                amountToSpend + entryFee <= cash
            ) {
                cash -=
                    amountToSpend + entryFee;

                btc = btcBought;

                entryPrice = candle.close;
                entryValue = amountToSpend;

                console.log(
                    `BUY         $${candle.close.toFixed(2)}`
                );
            }
        }

        /*
         * ==========================================
         * ACCOUNT VALUE / DRAWDOWN
         * ==========================================
         */

        const accountValue =
            cash + btc * candle.close;

        if (accountValue > peakBalance) {
            peakBalance = accountValue;
        }

        const drawdown =
            ((peakBalance - accountValue) /
                peakBalance) *
            100;

        if (drawdown > maxDrawdown) {
            maxDrawdown = drawdown;
        }
    }

    /*
     * ==========================================
     * CLOSE OPEN POSITION AT END OF TEST
     * ==========================================
     */

    if (btc > 0) {
        const finalPrice =
            candles[candles.length - 1].close;

        const exitValue =
            btc * finalPrice;

        const exitFee =
            exitValue * FEE_RATE;

        const entryFee =
            entryValue * FEE_RATE;

        const grossPnL =
            exitValue - entryValue;

        const totalFees =
            entryFee + exitFee;

        const netPnL =
            grossPnL - totalFees;

        cash +=
            exitValue - exitFee;

        trades.push({
            entryPrice,
            exitPrice: finalPrice,
            reason: "END OF TEST",
            grossPnL,
            fees: totalFees,
            netPnL,
        });

        if (netPnL >= 0) {
            winningTrades++;
        } else {
            losingTrades++;
        }

        console.log(
            `END OF TEST $${finalPrice.toFixed(2)} ` +
            `| P/L: $${netPnL.toFixed(2)}`
        );

        btc = 0;
    }

    /*
     * ==========================================
     * FINAL RESULTS
     * ==========================================
     */

    const finalBalance = cash;

    const totalPnL =
        finalBalance - STARTING_BALANCE;

    const winRate =
        trades.length > 0
            ? (winningTrades / trades.length) * 100
            : 0;

    console.log("\n==============================");
    console.log("       BACKTEST RESULTS");
    console.log("==============================");

    console.log(
        `Starting balance: $${STARTING_BALANCE.toFixed(2)}`
    );

    console.log(
        `Final balance:    $${finalBalance.toFixed(2)}`
    );

    console.log(
        `Total P/L:        $${totalPnL.toFixed(2)}`
    );

    console.log(
        `Trades:           ${trades.length}`
    );

    console.log(
        `Winning trades:   ${winningTrades}`
    );

    console.log(
        `Losing trades:    ${losingTrades}`
    );

    console.log(
        `Win rate:         ${winRate.toFixed(2)}%`
    );

    console.log(
        `Stop losses:      ${stopLossTrades}`
    );

    console.log(
        `Take profits:     ${takeProfitTrades}`
    );

    console.log(
        `Signal exits:     ${signalExitTrades}`
    );

    console.log(
        `Max drawdown:     ${maxDrawdown.toFixed(2)}%`
    );

    console.log("==============================\n");
}

runBacktest().catch((error) => {
    console.error(
        "Backtest error:",
        error.message
    );
});