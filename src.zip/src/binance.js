const BASE_URL = "https://api.binance.com";

async function getCandles(
    symbol = "BTCUSDT",
    interval = "1m",
    limit = 1000
) {
    const url =
        `${BASE_URL}/api/v3/klines` +
        `?symbol=${symbol}` +
        `&interval=${interval}` +
        `&limit=${limit + 1}`;

    const response = await fetch(url);

    if (!response.ok) {
        throw new Error(
            `Binance API error: ${response.status}`
        );
    }

    const data = await response.json();

    const candles = data.map((candle) => ({
        openTime: candle[0],
        open: Number(candle[1]),
        high: Number(candle[2]),
        low: Number(candle[3]),
        close: Number(candle[4]),
        volume: Number(candle[5]),
        closeTime: candle[6],
    }));

    const now = Date.now();

    return candles
        .filter((candle) => candle.closeTime <= now)
        .slice(-limit);
}

async function getHistoricalCandles(
    symbol = "BTCUSDT",
    interval = "1m",
    totalCandles = 5000
) {
    const allCandles = [];

    let endTime = Date.now();

    while (allCandles.length < totalCandles) {
        const remaining =
            totalCandles - allCandles.length;

        const batchSize = Math.min(
            1000,
            remaining
        );

        let url =
            `${BASE_URL}/api/v3/klines` +
            `?symbol=${symbol}` +
            `&interval=${interval}` +
            `&limit=${batchSize}`;

        if (endTime) {
            url += `&endTime=${endTime}`;
        }

        console.log(
            `Downloading candles... ${allCandles.length}/${totalCandles}`
        );

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(
                `Binance API error: ${response.status}`
            );
        }

        const data = await response.json();

        if (data.length === 0) {
            break;
        }

        const candles = data.map((candle) => ({
            openTime: candle[0],
            open: Number(candle[1]),
            high: Number(candle[2]),
            low: Number(candle[3]),
            close: Number(candle[4]),
            volume: Number(candle[5]),
            closeTime: candle[6],
        }));

        allCandles.unshift(...candles);

        // Move backwards in time
        endTime = candles[0].openTime - 1;

        // Prevent unnecessary requests
        if (data.length < batchSize) {
            break;
        }
    }

    // Remove duplicates
    const uniqueCandles = Array.from(
        new Map(
            allCandles.map((candle) => [
                candle.openTime,
                candle,
            ])
        ).values()
    );

    return uniqueCandles
        .sort((a, b) =>
            a.openTime - b.openTime
        )
        .slice(-totalCandles);
}

module.exports = {
    getCandles,
    getHistoricalCandles,
};