class PaperTrader {
    constructor(startingBalance = 1000, feeRate = 0.001) {
        this.startingBalance = startingBalance;

        this.cash = startingBalance;
        this.btc = 0;

        this.entryPrice = null;
        this.entryValue = null;

        this.trades = [];

        // 0.1% fee per trade
        this.feeRate = feeRate;

        this.realizedPnL = 0;
    }

    buy(price) {
        if (this.btc > 0) {
            console.log("Already holding BTC.");
            return;
        }

        // Use 10% of available cash
        const amountToSpend = this.cash * 0.10;

        const fee = amountToSpend * this.feeRate;

        const totalCost = amountToSpend + fee;

        if (totalCost > this.cash) {
            console.log("Not enough cash for this trade.");
            return;
        }

        const btcBought = amountToSpend / price;

        this.cash -= totalCost;
        this.btc = btcBought;

        this.entryPrice = price;
        this.entryValue = amountToSpend;

        console.log("\n🟢 PAPER BUY");
        console.log("------------------------------");
        console.log(`Price:       $${price.toFixed(2)}`);
        console.log(`BTC:         ${btcBought.toFixed(8)}`);
        console.log(`Position:    $${amountToSpend.toFixed(2)}`);
        console.log(`Fee:         $${fee.toFixed(2)}`);
        console.log("------------------------------");
    }

    sell(price) {
        if (this.btc <= 0) {
            console.log("No BTC to sell.");
            return;
        }

        const exitValue = this.btc * price;

        const fee = exitValue * this.feeRate;

        const netExitValue = exitValue - fee;

        const grossPnL = exitValue - this.entryValue;

        const totalFees =
            this.entryValue * this.feeRate + fee;

        const netPnL = grossPnL - totalFees;

        this.cash += netExitValue;

        this.realizedPnL += netPnL;

        const trade = {
            type: "ROUND_TRIP",
            entryPrice: this.entryPrice,
            exitPrice: price,
            quantity: this.btc,
            entryValue: this.entryValue,
            exitValue,
            fees: totalFees,
            grossPnL,
            netPnL,
            time: new Date().toISOString(),
        };

        this.trades.push(trade);

        console.log("\n🔴 PAPER SELL");
        console.log("------------------------------");
        console.log(`Entry:       $${this.entryPrice.toFixed(2)}`);
        console.log(`Exit:        $${price.toFixed(2)}`);
        console.log(`BTC:         ${this.btc.toFixed(8)}`);
        console.log(`Gross P/L:   $${grossPnL.toFixed(2)}`);
        console.log(`Fees:        $${totalFees.toFixed(2)}`);
        console.log(`Net P/L:     $${netPnL.toFixed(2)}`);
        console.log("------------------------------");

        this.btc = 0;
        this.entryPrice = null;
        this.entryValue = null;
    }

    getBalance(price) {
        return this.cash + this.btc * price;
    }

    getUnrealizedPnL(price) {
        if (this.btc <= 0) {
            return 0;
        }

        return (price - this.entryPrice) * this.btc;
    }

    getStatus(price) {
        const totalBalance = this.getBalance(price);
        const unrealizedPnL = this.getUnrealizedPnL(price);

        const totalPnL =
            totalBalance - this.startingBalance;

        console.log("\n========== ACCOUNT ==========");
        console.log(`Cash:          $${this.cash.toFixed(2)}`);
        console.log(`BTC:           ${this.btc.toFixed(8)}`);
        console.log(`Total:         $${totalBalance.toFixed(2)}`);
        console.log(`Realized P/L:  $${this.realizedPnL.toFixed(2)}`);
        console.log(`Unrealized P/L:$${unrealizedPnL.toFixed(2)}`);
        console.log(`Total P/L:     $${totalPnL.toFixed(2)}`);
        console.log(`Trades:        ${this.trades.length}`);
        console.log("==============================\n");
    }
}

module.exports = PaperTrader;