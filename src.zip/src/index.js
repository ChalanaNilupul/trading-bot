const { getCandles } = require("./binance");
const { getSignal, calculateSMA } = require("./strategy");
const PaperTrader = require("./paperTrader");

const SYMBOL = "BTCUSDT";
const INTERVAL = "1m";

const trader = new PaperTrader(1000);

async function runBot() {
    try {
        console.log("\n==============================");
        console.log("       TRADING BOT V1");
        console.log("==============================");

        const candles = await getCandles(
            SYMBOL,
            INTERVAL,
            100
        );

        if (candles.length < 50) {
            console.log("Not enough candle data.");
            return;
        }

        const latestCandle = candles[candles.length - 1];

        const closes = candles.map((candle) => candle.close);

        const fastMA = calculateSMA(closes, 20);
        const slowMA = calculateSMA(closes, 50);

        const signal = getSignal(candles);

        console.log(`Symbol: ${SYMBOL}`);
        console.log(`Candle: ${new Date(latestCandle.closeTime).toLocaleString()}`);
        console.log(`Price: $${latestCandle.close.toFixed(2)}`);
        console.log(`SMA 20: $${fastMA.toFixed(2)}`);
        console.log(`SMA 50: $${slowMA.toFixed(2)}`);
        console.log(`Signal: ${signal}`);

        if (signal === "BUY") {
            trader.buy(latestCandle.close);
        }

        if (signal === "SELL") {
            trader.sell(latestCandle.close);
        }

        trader.getStatus(latestCandle.close);

    } catch (error) {
        console.error("Bot error:", error.message);
    }
}

runBot();